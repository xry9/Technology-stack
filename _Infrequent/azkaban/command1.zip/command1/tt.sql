load data local inpath '/home/tyx/data/tt.txt' overwrite into table dbazkaban.tt;
