package model

//Data 结构
type Data struct {
	Amount      float64
	TotalAmount float64
	TotalCount  int64
}
