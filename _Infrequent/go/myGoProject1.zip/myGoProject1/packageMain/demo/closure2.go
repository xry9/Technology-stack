package main

import (
	"fmt"
	"strings"
)
func main() {
	add_func := add(1,2)
	fmt.Println(add_func())
	fmt.Println(add_func())
	fmt.Println(add_func())

	f := makeSuffic(".jpg")
	fmt.Println(f("route"))
}

// 闭包使用方法
func add(x1, x2 int) func()(int,int)  {
	i := 0
	return func() (int,int){
		i++
		return i,x1+x2
	}
}

func makeSuffic(suffix string) func(string) string {
	return func(name string) string {
		if ! strings.HasSuffix(name, suffix) {
			return name + suffix
		}
		return name
	}
}

