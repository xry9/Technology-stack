package main

import "fmt"

// 声明一个函数类型
type cb func(int) int

func main() {
	callBackTest(3, myCallback)
	callBackTest(4, func(i int) int {
		fmt.Println("I am inner ...")
		return i
	})

	cc := func(a int, b int) int { return a + b}(1, 2)
	fmt.Println(cc)
}

func callBackTest(x int, f cb) {
	fmt.Println(f(x))
}

func myCallback(i int) int {
	fmt.Println("===I am myCallback===")
	return i
}

