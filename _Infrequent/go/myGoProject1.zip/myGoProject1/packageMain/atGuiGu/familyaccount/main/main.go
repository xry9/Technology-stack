package main
import (
	//"myGoProject1/packageMain/atGuiGu/familyaccount/utils"
	"../utils"
	"fmt"
)
func main() {

	fmt.Println("这个是面向对象的方式完成~~")
	utils.NewFamilyAccount().MainMenu() //思路非常清晰
}