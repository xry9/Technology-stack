package main
import (
	"fmt"
)

type Stu struct {
	Name string
}

func (stu Stu) Say() {
	fmt.Println("Stu Say()")
}


type integer int

func (i integer) Say() {
	fmt.Println("integer Say i =" ,i )
}


type AInterface interface {
	Say()
}

type BInterface interface {
	Hello()
}

type Monster1 struct {

}
func (m Monster1) Hello() {
	fmt.Println("Monster1 Hello()~~")
}

func (m Monster1) Say() {
	fmt.Println("Monster1 Say()~~")
}

func main() {
	var stu Stu //结构体变量，实现了 Say() 实现了 AInterface
 	var a AInterface = stu
	a.Say()

	var i integer = 10
	var b AInterface = i
	b.Say() // integer Say i = 10

	//Monster实现了AInterface 和 BInterface
	var monster Monster1
	var a2 AInterface = monster
	var b2 BInterface = monster
	a2.Say()
	b2.Hello()
}