package main
import (
	"fmt"
)

//声明/定义一个接口
type Usb0 interface {
	//声明了两个没有实现的方法
	Start() 
	Stop()
}


//声明/定义一个接口
type Usb02 interface {
	//声明了两个没有实现的方法
	Start() 
	Stop()
	Test()
}



type Phone0 struct {

}  

//让Phone0 实现 Usb0接口的方法
func (p Phone0) Start() {
	fmt.Println("手机开始工作。。。")
}
func (p Phone0) Stop() {
	fmt.Println("手机停止工作。。。")
}

type Camera0 struct {

}
//让Camera0 实现   Usb0接口的方法
func (c Camera0) Start() {
	fmt.Println("相机开始工作~~~。。。")
}
func (c Camera0) Stop() {
	fmt.Println("相机停止工作。。。")
}


//计算机
type Computer0 struct {
}

//编写一个方法Working 方法，接收一个Usb0接口类型变量
//只要是实现了 Usb0接口 （所谓实现Usb0接口，就是指实现了 Usb0接口声明所有方法）
func (c Computer0) Working(Usb0 Usb0) {

	//通过Usb0接口变量来调用Start和Stop方法
	Usb0.Start()
	Usb0.Stop()
}

func main() {

	//测试
	//先创建结构体变量
	Computer0 := Computer0{}
	Phone0 := Phone0{}
	Camera0 := Camera0{}

	//关键点
	Computer0.Working(Phone0)
	Computer0.Working(Camera0) //
}